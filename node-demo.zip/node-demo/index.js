const redux =require ("redux")
// console.log(redux);


// Create base State Object
 const initialState={
     counter: 0, 
 };

 //Create a new Reducer
//  const reducer =(state = initialState,action)=>{
//      if(action.type ==="increment"){
//         return{
//          counter:state.counter+1,
//         };
//        } else if(action.type ==="decrement"){
//         return{
//          counter:state.counter-1,
//         };
//        } else{
//         return state;
//        }
       
//  };

const reducer=(state =initialState,action)=>{
    const{value,type}=action;
    switch(type){
    case "increment":
        //some code
      return {
          counter:state.counter + value,
      };
      
    case "decrement":
        //some code
      return {
          counter:state.counter - value,
      };
    
    case "multiplication":
        //some code
      return {
          counter:state.counter * value,
      };
    
    case "division":
        //some code
      return {
          counter:state.counter / value,
      };
    }
}




 //Create a new Store
 const store = redux.createStore(reducer);
//  console.log(store);


 //Create a Subsciption Handler
 const storeSubsciber =()=>{
     const currentState=store.getState();
     console.log(currentState);
 };



 //Subsciber to  the store
 store.subscribe(storeSubsciber);
 
 

 //Dispatch

 //Increment
 store.dispatch({type:"increment",value:10});

// store.dispatch({type:"increment"})
// store.dispatch({type:"increment"})
// store.dispatch({type:"increment"}) 

//Decrement
store.dispatch({type:"decrement",value:1});


//multiplication
store.dispatch({type:"multiplication",value:4});



//division
store.dispatch({type:"division",value:2});





